public class IV {
    int number = 10;
    public static void main(String[] args) {
        IV ob = new IV();
        System.out.println("Value of the number is "+ob.number);
    }
}
