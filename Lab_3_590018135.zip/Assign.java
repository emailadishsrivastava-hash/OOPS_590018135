public class Assign extends Test {
    public static void main(String [] args)
    {
        Assign ob = new Assign();
        int n = ob.Initialise(5);
        System.out.println(n);
    }    
}
